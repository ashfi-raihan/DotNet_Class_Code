﻿using Lab.Models;
using System.ComponentModel.DataAnnotations;

namespace Lab.Attributes
{
    public class GenderBasedAgeAttribute : ValidationAttribute
    {

        protected override ValidationResult? IsValid(object? value, ValidationContext context) // jei class e use hbe tar full object ta " ValidationContext " e eshe porbe.
        {
            if (value is DateTime dob)
            {
                var age = (DateTime.Now - dob).TotalDays / 365; // convert to years

                // Only for student class.
                //var modelData = (StudentModel)context.ObjectInstance; // ekhon student model er object ta k access korte parbo.
                //                                                      // shudhu student er jonnoi kaj korbe.

                //if(modelData.Gender == "Male" &&  age < 21)
                //{
                //    return new ValidationResult("min21");
                //}
                //if (modelData.Gender == "Female" && age < 18)
                //{
                //    return new ValidationResult("min18");
                //}
                // --------------------------------------------------------------------

                // for all available classes but only for "Gender" named property.

                var genderProp = context.ObjectType.GetProperty("Gender"); // context diye jei object ta ashlo, tar "Gender" name property theke gender k access korlm.

                if (genderProp == null) // check korlm "Gender" name kono property chilo kina context er thaka object e.
                {
                    return new ValidationResult("Invalid gender Property.");
                }

                var gen = genderProp.GetValue(context.ObjectInstance); // jodi context e "Gender" name property thake tobe tar value nilm.
                                                                       // context.ObjectInstance -> object er full value achhe.

                if (gen != null && gen == "Male" && age < 21)
                {
                    return new ValidationResult("min21");
                }
                if (gen != null && gen == "Female" && age < 18)
                {
                    return new ValidationResult("min18");


                    // basic
                    //if(age < 18)
                    //{
                    //    return new ValidationResult("min18");
                    //}
                }
            }
            else
            {
                return new ValidationResult("Invalid Date Formate.");
            }
            return ValidationResult.Success;
        }
    }
}
