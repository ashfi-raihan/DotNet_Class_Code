﻿using Lab.Data;
using Lab.Data.Entities;
using Microsoft.AspNetCore.Mvc;

namespace Lab.Controllers
{
    public class DepartmentController(Fall2627DbContext _context) : Controller
    {
        // db setup for this page. but eta lenghty onk and upore brackect e use kora bshi easy.
        //public Fall2627DbContext _context; // db shb jagay use korbo so ekta property nilm jate constructor er help niye db er object k store korbo. 
        //public DepartmentController(Fall2627DbContext context)  // db er ekta object ashche and oita k dhorte ekta variable nilm.
        //{
        //    _context = context;
        //}


        public IActionResult Index()
        {
            var departments = _context.Departments.ToList(); //_context.Departments diye database class e departments name ekta property ase oitai anlm
                                                            // tolist() cz property ta ekta list. tolist diye shb data niye ashlm. 
            return View(departments);
        }

        public IActionResult Delete(int did) 
        {
            var dept = _context.Departments.Find(did); // find() db table theke value match kore niye ashbe.

            if (dept == null) 
            {
                TempData["Error"] = "Invalid ID"; // viewbag and viewdata redirect support kore na. jodi delete er e view te jetam tahole eigula use korte partm bt amra delete theke retun diye index jbo tai egula support korbe na.
                                                  // tempdata redirect support kore.
            }
            else
            {
                _context.Departments.Remove(dept); // departments er variable _context theke delete hbe shudhu.
                _context.SaveChanges(); // department er shb change db te permanantly change hbe.
                TempData["Success"] = "Deleted!";
            }
                return RedirectToAction("Index");
        }


        [HttpGet]
        public IActionResult Create()
        {
            return View(new Department());
        }
        [HttpPost]
        public IActionResult Create(Department dept)
        {
            if(ModelState.IsValid == false) // jodi input value vul thake tahole just dept k return kore dicchi.
            {
                return View(dept);
            }

            _context.Departments.Add(dept); // data thik thakle add kore dilm.
            _context.SaveChanges();
            TempData["Success"] = "Department Added.";
            return RedirectToAction("Index");
        }


        [HttpGet]
        public IActionResult Edit(int did) // view side e edit button click e ekta id ashbe oitai catch korlm.
        {
            var dept = _context.Departments.Find(did); // jei id eshe chilo sheta k use kore dept ta anlm.
            return View();  // dept ta kei return korlm.
        }
        [HttpPost]
        public IActionResult Edit(Department dept)
        {
            if (ModelState.IsValid == false) // jodi input value vul thake tahole just dept k return kore dicchi.
            {
                return View(dept);
            }

            _context.Departments.Update(dept); // data thik thakle add kore dilm.
            _context.SaveChanges();
            TempData["Success"] = "Department Updated.";
            return RedirectToAction("Index");
        }
    }
}
