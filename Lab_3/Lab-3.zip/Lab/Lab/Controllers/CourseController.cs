﻿using Microsoft.AspNetCore.Mvc;

namespace Lab.Controllers
{
    [Route("Subject")] // Controller er nam change kore disi. shb func  er jonno ekhn route likhte hbe,
    public class CourseController : Controller
    {
        public IActionResult Index()
        {
            return Content("Hello World");
        }

        public IActionResult Msg()
        {
            return Content("Msg");
        }

        [Route("Details/{cid:int}")]
        public IActionResult Details(int cid)
        {
            ViewBag.Message = "This is the details of course " + cid;
            return View();
        }
        
        [Route("CourseList")] // ekhon function er name change korleo "CourseList" likhlei hbe.
        [Route("Course/List")] // eta na likhle default ta use kora jbe na.
        public IActionResult List()
        {
            ViewBag.Title = "Exsisting Course Title";
            ViewData["Desc"] = "Couse description";
            return View();
        }

        [Route("check/{id:int}")]
        public IActionResult Check(int id)
        {
            if (id == 1)
            {
                return Json(new { id = 1, name = "ABC", dept = "cse" });
            }
            else if (id == 2)
            {
                return Redirect("https://www.aiub.edu");
            }
            else if (id == 3)
            {
                return RedirectToAction("Privacy", "Home");
            }
            else if (id == 4)
            {
                var cssFile = System.IO.File.ReadAllBytes("wwwroot/css/site.css");
                return File(cssFile, "text/css", "Test.css");
            }
            else if (id == 5)
            {
                return RedirectToAction("Msg");
            }
            else
            {
                return NotFound();
            }
        } 

        public IActionResult RouteCheck(int id)
        {
            return Content(id.ToString()); // id er jagay cid likhle auto value set hoito na 
                                           // abr duita value dileo hoito jodi func er parameter p1 hoito but url: Course/RouteCheck/5/6
        }


        [Route("GetDay/{year:int:min(1900):max(9999):length(4)}/{month:int:min(1):max(12)}/{day:int:min(1):max(31)}")]
        public IActionResult GetDayOfDate(int year, int month, int day)
        {
            return Content("Blah Blah");
        }
    }
}
