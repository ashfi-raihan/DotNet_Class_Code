﻿using Microsoft.AspNetCore.Mvc;
using Lab.Data.Entities;
using Lab.Data;

namespace Lab.Controllers
{
    public class MajorController(Fall2627DbContext _context) : Controller
    {
        public IActionResult Index()
        {
            var majors = _context.Majors.ToList(); // shb data anar jonno
            // var majors = _context.Majors.Where(e => e.TotalTuitionFee/e.TotalCredit > 5500 && e.TotalCredit > 125).ToList(); // data filter kore hoyeche, "Where" diye. eta database e jei where use kori oitar motoi.
                                                                                                      // e holo shb gulo column k represent kore tai e diye shb column access kora jay.  
            
            return View(majors);
        }
    }
}
