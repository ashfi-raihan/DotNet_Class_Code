using System;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");
//pattern: "{controller=Home}/{action=Index}/{id:int:min(1):max(12)}");

app.MapControllerRoute(
    name: "default2",
    pattern: "abc/{controller=Home}/{action=Index}/{id?}");

app.MapControllerRoute(
    name: "default3",
    pattern: "{controller=Home}/{action=Index}/{p1?}/{p2?}");

app.MapControllerRoute(  // Course/List er jagay just CourseList likhlei hbe
    name: "courses",
    pattern: "CourseList",
    defaults: new{Controller="Course", Action="List"} ); // action or func er name "List" thke onno kichu dile eta r kaj korbe na. Tai attribute function use korte hbe.

app.Run();
