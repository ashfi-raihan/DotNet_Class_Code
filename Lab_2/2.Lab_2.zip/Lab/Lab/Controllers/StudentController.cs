﻿using Lab.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Lab.Controllers
{
    public class StudentController : Controller
    {
        public IActionResult Registration()
        {
            // options gulo server side thke pathano holo.
            //var genderList = new List<SelectListItem>();

            ////var male = new List<SelectListItem();
            ////male.Text = "Male";
            ////male.Value = "Male";
            ////genderList.Add(male);

            //genderList.Add(new SelectListItem() 
            //{ 
            //    Value = "Male", Text = "Male"
            //});

            //genderList.Add(new SelectListItem()
            //{
            //    Value = "Female",
            //    Text = "Female"
            //});

            //ViewBag.GenderList = genderList;


            // --- Protibar call na kore ekta function e banay fellm.
            this.LoadSupportingData();

            return View( new StudentModel());
        }

        [HttpPost]
        public IActionResult Registration(StudentModel model)
        {
            //if(model.FullName == " ")
            //{
            //    // error
            //}

            //if(model.Age<15 || model.Age > 60)
            //{
            //    // error
            //    ViewBag.Error = "Age15";
            //}

            if (model.FullName == "abc")
            {
                // ViewBag.Error = "Abc exits";
                ModelState.AddModelError("FullName", "Abc already exits"); // for a specific property. for asp-validation-summary="All"
            }

            if (model.FullName == "abc" && model.Age == 35)
            {
                // ViewBag.Error = "Abc exits";
                ModelState.AddModelError("", "Abc can not be 35");  // not for a specific property. For asp-validation-summary="ModelOnly"
            }

            //===========================================================================================
            //// server side theke data pathile get and post version both thekei pathaite hbe.
            //var genderList = new List<SelectListItem>();

            ////var male = new List<SelectListItem();
            ////male.Text = "Male";
            ////male.Value = "Male";
            ////genderList.Add(male);

            //genderList.Add(new SelectListItem()
            //{
            //    Value = "Male",
            //    Text = "Male"
            //});

            //genderList.Add(new SelectListItem()
            //{
            //    Value = "Female",
            //    Text = "Female"
            //});

            //ViewBag.GenderList = genderList;

            // --- Protibar call na kore ekta function e banay fellm.
            this.LoadSupportingData();

            //return View(model); // to show the output even after the data came after pressing submit button.

            if (ModelState.IsValid == false)
            {

                return View(model); // to show the output even after the data came after pressing submit button.
            }
            else
            {
                return View("Succes", model);
            }
        }

        public void LoadSupportingData()
        {
            // server side theke data pathile get and post version both thekei pathaite hbe.
            var genderList = new List<SelectListItem>();

            //var male = new List<SelectListItem();
            //male.Text = "Male";
            //male.Value = "Male";
            //genderList.Add(male);

            genderList.Add(new SelectListItem()
            {
                Value = "Male",
                Text = "Male"
            });

            genderList.Add(new SelectListItem()
            {
                Value = "Female",
                Text = "Female"
            });

            ViewBag.GenderList = genderList;
        }

    }
}
