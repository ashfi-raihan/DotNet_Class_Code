﻿using Microsoft.AspNetCore.Mvc;

namespace Lab.Controllers
{
    public class ViewExampleController : Controller
    {
        public IActionResult Index(int p1, int p2)
        {
            ViewBag.start = p1;
            ViewBag.end = p2;
            return View(5);
        }

        public IActionResult CheckData(int id)
        {
            switch (id)
            {
                case 1:
                    return View(5);
                case 2:
                    return View(5.5);
                case 3:
                    return View("CheckData", "Hello");
                case 4:
                    return View(new {Name = "Hello", ID="4"});
            }
            return View(0);
        }
    }
}
