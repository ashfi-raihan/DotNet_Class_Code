﻿using System.ComponentModel.DataAnnotations;
using Lab.Attributes; // import kore nite hbe.

namespace Lab.Models
{
    public class StudentModel
    {

        // eikhaner protita specific property based. for asp-validation-summary="All"
        // asp-validation-summary="ModelOnly" te dekhabe na.

        [Required(ErrorMessage ="Name Required")]
        [StringLength(500,MinimumLength =20, ErrorMessage ="Name 10 &500")]
        [Display(Name = "Full Name")]
        public string FullName {get; set;}





        //[Range(15,60, ErrorMessage ="Age-15&60")]
        [MinValue(15, ErrorMessage ="minAge-15")]
        public int Age {get; set;}

        [Required]
        public string Gender { get; set;}


        [Required]
        [GenderBasedAge]
        [Display(Name = "Date Of Birth")]
        public DateTime DateOfBirth { get; set;}
    }
}
