﻿using System.ComponentModel.DataAnnotations;

namespace Lab.Attributes
{

    // custom attribute validation client side ei hbe. debug e  controller e dhora porve. _ValidationScriptsPartial use korleo same e hbe.
    public class MinValueAttribute : ValidationAttribute
    {
        public int mv;

        public MinValueAttribute(int _mv) 
        {
            mv = _mv;
        }
        public override bool IsValid(object? value)
        {
            if(value is int a) // value ki int kina check kore a te store.
            {
                if (a < mv)
                {
                    return false;
                }
            }
            else
            {
                return false; 
            }

            return true;
        }
    }
}
