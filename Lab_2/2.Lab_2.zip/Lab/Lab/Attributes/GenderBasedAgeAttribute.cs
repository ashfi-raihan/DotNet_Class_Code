﻿using Lab.Models;
using System.ComponentModel.DataAnnotations;

namespace Lab.Attributes
{
    public class GenderBasedAgeAttribute : ValidationAttribute
    {

        protected override ValidationResult? IsValid(object? value, ValidationContext context) // jei class e use hbe tar full object ta " ValidationContext " e eshe porbe.
        {
            if (value is DateTime dob)
            {
                var age = (DateTime.Now - dob).TotalDays / 365; // convert to years
                var modelData = (StudentModel)context.ObjectInstance; // ekhon student model er object ta k access korte parbo.

                if(modelData.Gender == "Male" &&  age < 21)
                {
                    return new ValidationResult("min21");
                }
                if (modelData.Gender == "Female" && age < 18)
                {
                    return new ValidationResult("min18");
                }
                // basic
                //if(age < 18)
                //{
                //    return new ValidationResult("min18");
                //}
            }
            else
            {
                return new ValidationResult("Invalid Date Formate.");
            }
            return ValidationResult.Success;
        }
    }
}
