﻿using Microsoft.AspNetCore.Mvc;

namespace abc.Controllers
{
    public class courseController : Controller
    {
        public IActionResult Index()
        {
            return Content("Hello World");
        }

        public IActionResult Msg() 
        {
            return Content("Msg");
        }

        public IActionResult Details(int id)
        {
            ViewBag.Message = "This is the details of course " + id;
            return View();
        }
        public IActionResult List()
        {
            ViewBag.Title = "Exsisting Couse Title";
            ViewData["Desc"] = "Couse description";
            return View();
        }

        public IActionResult Check(int id)
        {
            if(id == 1)
            {
                return Json(new { id = 1, name = "ABC", dept = "cse" });
            }
            else if (id == 2)
            {
                return Redirect("https://www.aiub.edu");
            }
            else if(id == 3)
            {
                return RedirectToAction("Privacy", "Home");
            }
            else if(id == 4)
            {
                var cssFile = System.IO.File.ReadAllBytes("wwwroot/css/site.css");
                return File(cssFile, "text/css", "Test.css");
            }
            else if (id == 5)
            {
                return RedirectToAction("Msg");
            }
            else
            {
                return NotFound();
            }
        }
    }
}
